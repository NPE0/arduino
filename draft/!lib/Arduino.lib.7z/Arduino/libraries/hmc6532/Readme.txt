
BETA: WARNING: BETA: WARNING: BETA: WARNING: BETA: 

This library is BETA, only tested partially and not thoroughly
No guarantees, use at own risk, all disclaimers apply 
The example sketch can be used to config the compass.
For switching operational mode one must reboot the system.

WARNING: BETA: WARNING: BETA: WARNING: BETA: WARNING: 

